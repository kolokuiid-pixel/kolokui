-- Kolokui: jalankan SEKALI di Supabase > SQL Editor > New query > Run.

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  rubrik text not null check (rubrik in ('senja', 'sabda', 'omk', 'ziarah')),
  slug text not null,
  title text not null,
  date date not null default current_date,
  ringkasan text not null default '',
  body text not null default '',
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (rubrik, slug)
);

create index if not exists posts_published_date_idx
  on public.posts (published, date desc);

create table if not exists public.pustaka (
  id uuid primary key default gen_random_uuid(),
  judul text not null,
  jenis text not null,
  tahun text not null default '',
  file_path text,
  created_at timestamptz not null default now()
);

-- RLS aktif TANPA policy: kunci publik (anon) tidak bisa membaca atau menulis tabel.
-- Semua akses lewat server Next.js memakai service role key, jadi draf tidak pernah bocor.
alter table public.posts enable row level security;
alter table public.pustaka enable row level security;

-- Bucket file Pustaka. Publik untuk diunduh; upload hanya lewat tautan bertanda tangan dari admin.
insert into storage.buckets (id, name, public)
values ('pustaka', 'pustaka', true)
on conflict (id) do nothing;
