// Sesi admin: cookie "<kedaluwarsa>.<tanda tangan HMAC>". Memakai Web Crypto supaya jalan
// di middleware (Edge) maupun di server Node.

export const COOKIE_NAME = "kolokui_admin";
export const SESSION_MAX_AGE = 60 * 60 * 24 * 7; // 7 hari

const enc = new TextEncoder();

function getSecret(): string | null {
  const s = process.env.ADMIN_SESSION_SECRET;
  return s && s.length >= 16 ? s : null;
}

async function hmac(data: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function createSession(): Promise<string> {
  const secret = getSecret();
  if (!secret) throw new Error("ADMIN_SESSION_SECRET belum diatur (min. 16 karakter).");
  const payload = String(Date.now() + SESSION_MAX_AGE * 1000);
  return `${payload}.${await hmac(payload, secret)}`;
}

export async function verifySession(value: string | undefined): Promise<boolean> {
  if (!value) return false;
  const secret = getSecret();
  if (!secret) return false;
  const [payload, sig] = value.split(".");
  if (!payload || !sig) return false;
  const expires = Number(payload);
  if (!Number.isFinite(expires) || expires < Date.now()) return false;
  try {
    return safeEqual(sig, await hmac(payload, secret));
  } catch {
    return false;
  }
}

/** Membandingkan password lewat HMAC supaya panjang dan waktu bandingnya tidak membocorkan apa-apa. */
export async function checkPassword(
  input: string,
): Promise<"ok" | "wrong" | "unconfigured"> {
  const expected = process.env.ADMIN_PASSWORD;
  const secret = getSecret();
  if (!expected || !secret) return "unconfigured";
  const [a, b] = await Promise.all([
    hmac(`pw:${input}`, secret),
    hmac(`pw:${expected}`, secret),
  ]);
  return safeEqual(a, b) ? "ok" : "wrong";
}
