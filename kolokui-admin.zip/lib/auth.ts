import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { COOKIE_NAME, verifySession } from "./session";

/** Panggil di setiap halaman dan aksi admin, sebagai lapisan kedua setelah middleware. */
export async function requireAdmin(): Promise<void> {
  const value = (await cookies()).get(COOKIE_NAME)?.value;
  if (!(await verifySession(value))) redirect("/admin/login");
}
