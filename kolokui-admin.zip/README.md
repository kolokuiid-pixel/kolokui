# Kolokui

Website renungan: Percakapan dengan Tuhan, sesama, dan hidup.
Next.js (App Router) + Supabase (database dan file Pustaka). Siap deploy ke Vercel.

## Setup sekali jalan

1. **Supabase**: buat project di supabase.com (region Singapore paling dekat).
   Buka **SQL Editor > New query**, tempel isi `supabase/schema.sql`, klik **Run**.
   Ini membuat tabel `posts`, `pustaka`, dan bucket file `pustaka`.
2. **Ambil kunci** di **Project Settings > API**: Project URL, kunci `anon`/`publishable`, dan kunci `service_role`/`secret`.
3. **Buat `.env.local`** (contoh ada di `.env.example`):

   | Variabel | Isi |
   | --- | --- |
   | `NEXT_PUBLIC_SUPABASE_URL` | Project URL |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | kunci anon / publishable |
   | `SUPABASE_SERVICE_ROLE_KEY` | kunci service_role / secret. **Rahasia**, jangan dibagikan |
   | `ADMIN_PASSWORD` | password login admin |
   | `ADMIN_SESSION_SECRET` | teks acak, min. 16 karakter. `openssl rand -hex 32` |
   | `NEXT_PUBLIC_CONTACT_EMAIL` | tujuan formulir Ajak Bercakap |

4. Jalankan:

   ```bash
   npm install
   npm run dev     # http://localhost:3000
   ```

5. Buka `/admin`, masuk dengan `ADMIN_PASSWORD`.

## Deploy ke Vercel

Isi **semua variabel yang sama** di Vercel > Project > Settings > Environment Variables, lalu deploy ulang.
Tulisan yang diterbitkan dari admin langsung muncul di situs (maksimal sekitar satu menit).

## Memakai admin

- **Tulisan**: daftar semua tulisan (terbit dan draf). "Tulisan baru" membuka editor.
  Isi ditulis dengan Markdown sederhana: baris kosong = paragraf baru, `## Subjudul`, `> kutipan ayat`, `**tebal**`, `*miring*`.
  Tombol **Pratinjau** menampilkan tampilan akhirnya. **Simpan sebagai draf** tidak tampil di situs.
- **Pustaka**: tambah bahan (judul, jenis, tahun, file PDF/Word/PowerPoint/Excel/ZIP). File boleh dikosongkan, di situs tampil "Segera tersedia".
  Untuk mengganti file, hapus bahan lalu tambah lagi.

## Keamanan

- Login memakai satu password bersama dan cookie bertanda tangan (HttpOnly, berlaku 7 hari).
- Tabel database tidak bisa diakses langsung dari browser (RLS aktif tanpa policy). Semua baca-tulis lewat server.
- Belum ada pembatasan percobaan login selain jeda kecil saat salah. Pakai password yang panjang.

## Catatan

Folder `content/` dan paket `gray-matter` dari versi awal sudah tidak dipakai. Folder `content/` boleh dihapus.
