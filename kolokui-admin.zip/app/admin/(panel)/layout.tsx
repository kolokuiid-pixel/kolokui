import { requireAdmin } from "@/lib/auth";
import AdminNav from "./AdminNav";

export default async function PanelLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  await requireAdmin();
  return (
    <div className="wrap">
      <AdminNav />
      {children}
    </div>
  );
}
