"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { logout } from "@/app/admin/actions";

export default function AdminNav() {
  const pathname = usePathname();
  const onPustaka = pathname.startsWith("/admin/pustaka");

  return (
    <div className="admin-bar">
      <Link href="/admin" className="logo">
        Kolokui Admin
      </Link>
      <nav aria-label="Menu admin">
        <Link href="/admin" aria-current={!onPustaka ? "page" : undefined}>
          Tulisan
        </Link>
        <Link
          href="/admin/pustaka"
          aria-current={onPustaka ? "page" : undefined}
        >
          Pustaka
        </Link>
        <Link href="/" target="_blank" rel="noopener">
          Lihat situs
        </Link>
        <form action={logout}>
          <button type="submit" className="link-btn">
            Keluar
          </button>
        </form>
      </nav>
    </div>
  );
}
