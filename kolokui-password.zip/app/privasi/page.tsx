import type { Metadata } from "next";
import Link from "next/link";
import LegalPage, { KONTAK } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: "Kebijakan Privasi",
  description: "Data apa yang kami kumpulkan di Kolokui, untuk apa, dan hak-hakmu atas data itu.",
};

export default function Privasi() {
  return (
    <LegalPage judul="Kebijakan Privasi">
      <p>
        Kolokui adalah situs renungan dan tulisan rohani. Kebijakan ini menjelaskan data pribadi
        apa yang kami kumpulkan saat kamu memakai situs ini, untuk apa data itu dipakai, dan apa
        saja hakmu. Kami berusaha mengumpulkan sesedikit mungkin.
      </p>

      <h2>1. Siapa kami</h2>
      <p>
        Kolokui dikelola oleh pengelola situs bersama Romo sebagai penulis. Untuk pertanyaan
        tentang data pribadimu, hubungi {KONTAK}.
      </p>

      <h2>2. Data yang kami kumpulkan</h2>
      <p>Kamu bisa membaca semua tulisan tanpa membuat akun. Data baru kami kumpulkan kalau kamu mendaftar atau memakai fitur komunitas:</p>
      <ul>
        <li>
          <strong>Akun:</strong> alamat email, nama tampilan, dan password. Password disimpan
          dalam bentuk terenkripsi (hash) oleh penyedia layanan autentikasi kami. Kami tidak bisa
          membacanya. Kalau kamu masuk dengan Google, kami menerima nama dan email dari akun
          Googlemu, bukan password Google.
        </li>
        <li>
          <strong>Komentar:</strong> isi komentar, nama tampilan, dan waktu pengiriman. Komentar
          bersifat publik dan bisa dibaca siapa saja.
        </li>
        <li>
          <strong>Pesan ke Romo:</strong> isi pesan dan balasan, beserta waktunya. Pesan ini tidak
          ditampilkan di situs.
        </li>
        <li>
          <strong>Data teknis:</strong> alamat IP, jenis peramban, dan catatan akses yang dibuat
          otomatis oleh penyedia hosting untuk keamanan dan kelancaran situs.
        </li>
      </ul>
      <p>Kami tidak memasang iklan dan tidak menjual data pribadimu.</p>

      <h2>3. Untuk apa data dipakai</h2>
      <ul>
        <li>Membuat dan mengamankan akunmu.</li>
        <li>Menampilkan komentarmu dan memungkinkan Romo membaca serta membalas pesanmu.</li>
        <li>Mengirim email yang berkaitan dengan akunmu: konfirmasi pendaftaran, atur ulang password, dan pemberitahuan bahwa ada pesan atau balasan baru. Email pemberitahuan tidak memuat isi pesan.</li>
        <li>Menjaga situs tetap aman, termasuk membatasi spam dan menyembunyikan komentar yang melanggar aturan.</li>
      </ul>
      <p>Dasar pemrosesannya adalah persetujuanmu saat mendaftar dan kepentingan sah untuk menjalankan situs.</p>

      <h2>4. Siapa yang bisa melihat datamu</h2>
      <ul>
        <li><strong>Pengunjung lain:</strong> hanya komentar dan nama tampilanmu.</li>
        <li>
          <strong>Romo:</strong> pesan pribadimu, nama tampilan, dan emailmu agar bisa membalas.
        </li>
        <li>
          <strong>Pengelola situs:</strong> komentar dan nama tampilanmu untuk moderasi. Pengelola
          tidak membaca pesan pribadi lewat situs ini.
        </li>
        <li>
          <strong>Penyedia layanan teknis:</strong> kami memakai Supabase (basis data, autentikasi,
          dan penyimpanan), Vercel (hosting), Resend (pengiriman email), dan Google (kalau kamu
          memilih masuk dengan Google). Mereka memproses data atas nama kami. Karena penyedia
          layanan secara teknis mengelola server tempat data disimpan, akses teknis di tingkat
          infrastruktur tidak bisa dikatakan nol.
        </li>
      </ul>
      <p>
        Data bisa diproses di server di luar Indonesia. Kami memilih penyedia yang menerapkan
        standar keamanan yang wajar.
      </p>

      <h2>5. Berapa lama disimpan</h2>
      <p>
        Data akun, komentar, dan pesan disimpan selama akunmu aktif. Kalau kamu meminta penghapusan,
        kami menghapus akun beserta komentar dan pesanmu, kecuali ada kewajiban hukum untuk
        menyimpannya. Catatan teknis disimpan oleh penyedia hosting sesuai kebijakan mereka.
      </p>

      <h2>6. Cookie dan penyimpanan di peramban</h2>
      <p>
        Kami memakai penyimpanan peramban (local storage) untuk menjaga kamu tetap masuk, dan
        cookie sesi untuk halaman pengelola. Keduanya diperlukan agar situs berfungsi. Kami tidak
        memakai cookie iklan atau pelacak pihak ketiga.
      </p>

      <h2>7. Hakmu</h2>
      <p>Sesuai Undang-Undang Nomor 27 Tahun 2022 tentang Pelindungan Data Pribadi, kamu berhak untuk:</p>
      <ul>
        <li>mengetahui dan meminta salinan data pribadimu;</li>
        <li>memperbaiki data yang keliru (nama bisa kamu ubah sendiri di halaman Akun);</li>
        <li>meminta penghapusan datamu dan akunmu;</li>
        <li>menarik persetujuan dan keberatan atas pemrosesan tertentu.</li>
      </ul>
      <p>
        Kirim permintaanmu ke {KONTAK} dari email yang terdaftar. Kami berusaha menanggapi dalam
        waktu yang wajar, paling lambat 3 x 24 jam untuk konfirmasi penerimaan.
      </p>

      <h2>8. Keamanan</h2>
      <p>
        Koneksi ke situs memakai HTTPS, password tidak disimpan sebagai teks biasa, dan akses ke
        basis data dibatasi lewat server. Tidak ada sistem yang seratus persen aman. Kalau terjadi
        kebocoran yang berdampak padamu, kami akan memberi tahu sesuai ketentuan hukum.
      </p>

      <h2>9. Pesan ke Romo bukan layanan darurat</h2>
      <p>
        Romo membalas ketika sempat, bisa memakan waktu beberapa hari. Pesan lewat situs ini tidak
        menggantikan pengakuan dosa, konseling profesional, atau bantuan darurat. Kalau kamu atau
        orang lain dalam bahaya, hubungi layanan darurat setempat atau pastor parokimu.
      </p>

      <h2>10. Anak-anak</h2>
      <p>
        Akun ditujukan untuk pengunjung berusia 17 tahun ke atas, atau yang sudah mendapat izin
        orang tua atau wali. Kalau kamu orang tua dan mengetahui anakmu mendaftar tanpa izin,
        hubungi kami agar akunnya kami hapus.
      </p>

      <h2>11. Perubahan kebijakan</h2>
      <p>
        Kebijakan ini bisa kami perbarui. Tanggal pembaruan terakhir selalu tercantum di atas.
        Untuk perubahan penting, kami akan memberi tahu lewat situs atau email.
      </p>

      <p>
        Lihat juga <Link href="/syarat">Syarat dan Ketentuan</Link>.
      </p>
    </LegalPage>
  );
}
