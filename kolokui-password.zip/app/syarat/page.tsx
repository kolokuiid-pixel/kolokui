import type { Metadata } from "next";
import Link from "next/link";
import LegalPage, { KONTAK } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: "Syarat dan Ketentuan",
  description: "Aturan memakai Kolokui, termasuk berkomentar dan mengirim pesan.",
};

export default function Syarat() {
  return (
    <LegalPage judul="Syarat dan Ketentuan">
      <p>
        Dengan memakai Kolokui, termasuk membuat akun, berkomentar, atau mengirim pesan, kamu
        menyetujui syarat berikut. Kalau tidak setuju, kamu tetap boleh membaca tulisan tanpa
        akun, tetapi sebaiknya tidak memakai fitur akun.
      </p>

      <h2>1. Tentang Kolokui</h2>
      <p>
        Kolokui adalah situs renungan dan tulisan rohani. Isinya adalah pandangan dan refleksi
        pribadi penulisnya, bukan pengajaran resmi Gereja atau keuskupan, kecuali dinyatakan
        demikian.
      </p>

      <h2>2. Akun</h2>
      <ul>
        <li>Kamu perlu akun untuk berkomentar dan mengirim pesan. Akun ditujukan untuk pengguna berusia 17 tahun ke atas, atau dengan izin orang tua atau wali.</li>
        <li>Berikan email yang benar dan milikmu sendiri.</li>
        <li>Jaga kerahasiaan passwordmu. Kegiatan lewat akunmu menjadi tanggung jawabmu.</li>
        <li>Satu orang cukup satu akun.</li>
      </ul>

      <h2>3. Aturan berkomentar dan berpesan</h2>
      <p>Kolokui ingin menjadi ruang percakapan yang tenang dan saling menghormati. Karena itu, kamu tidak diperkenankan:</p>
      <ul>
        <li>menghina, melecehkan, mengancam, atau merendahkan orang lain, termasuk berdasarkan suku, agama, ras, antargolongan, gender, atau kondisi tertentu;</li>
        <li>menyebarkan kebencian, kabar bohong, atau konten yang melanggar hukum;</li>
        <li>mengunggah konten pornografi, kekerasan, atau yang tidak pantas;</li>
        <li>mengiklankan, menyebarkan spam, atau menautkan ke situs berbahaya;</li>
        <li>membagikan data pribadi orang lain tanpa izin;</li>
        <li>mengirim pesan berulang atau mengganggu kepada Romo atau pengunjung lain;</li>
        <li>meniru identitas orang lain.</li>
      </ul>

      <h2>4. Moderasi</h2>
      <p>
        Komentar tampil langsung tanpa disaring lebih dulu. Pengelola berhak menyembunyikan atau
        menghapus komentar, serta memblokir akun yang melanggar aturan, dengan atau tanpa
        pemberitahuan sebelumnya. Kamu bisa menghapus komentarmu sendiri kapan saja.
      </p>

      <h2>5. Isi yang kamu kirim</h2>
      <p>
        Komentar dan pesan tetap menjadi milikmu. Dengan mengirim komentar, kamu mengizinkan
        Kolokui menampilkannya di situs ini selama komentar itu ada. Kamu bertanggung jawab atas
        isi yang kamu kirim.
      </p>

      <h2>6. Hak cipta tulisan</h2>
      <p>
        Tulisan, gambar, dan bahan di Kolokui dilindungi hak cipta. Kamu boleh membaca, membagikan
        tautannya, dan mengutip sebagian kecil dengan mencantumkan sumber. Menyalin seluruh
        tulisan, atau memakainya untuk keperluan komersial, memerlukan izin tertulis. Bahan di
        Pustaka dapat diunduh untuk keperluan pribadi atau pendampingan, kecuali dinyatakan lain.
      </p>

      <h2>7. Pesan ke Romo</h2>
      <ul>
        <li>Romo membalas ketika sempat dan tidak menjamin waktu balasan.</li>
        <li>Pesan lewat situs bukan layanan darurat, bukan pengakuan dosa, dan bukan pengganti konseling profesional atau bantuan medis. Untuk keadaan mendesak, hubungi layanan darurat setempat atau pastor parokimu.</li>
        <li>Kami menjaga agar pesan pribadi hanya dibuka oleh Romo di dalam situs. Lihat <Link href="/privasi">Kebijakan Privasi</Link> untuk penjelasan lengkap.</li>
      </ul>

      <h2>8. Ketersediaan layanan</h2>
      <p>
        Kami berusaha menjaga situs tetap berjalan, tetapi tidak menjamin situs selalu tersedia
        tanpa gangguan. Fitur bisa diubah atau dihentikan sewaktu-waktu.
      </p>

      <h2>9. Batas tanggung jawab</h2>
      <p>
        Situs disediakan apa adanya. Sejauh diizinkan hukum, pengelola tidak bertanggung jawab atas
        kerugian yang timbul dari pemakaian situs, dari isi komentar pengunjung lain, atau dari
        gangguan layanan. Pendapat dalam komentar adalah milik penulis komentar masing-masing.
      </p>

      <h2>10. Penutupan akun</h2>
      <p>
        Kamu boleh berhenti memakai situs kapan saja dan meminta akunmu dihapus lewat {KONTAK}.
        Kami dapat menangguhkan atau menutup akun yang melanggar syarat ini.
      </p>

      <h2>11. Perubahan syarat</h2>
      <p>
        Syarat ini bisa diperbarui. Dengan terus memakai situs setelah pembaruan, kamu dianggap
        menyetujui versi terbaru. Tanggal pembaruan terakhir tercantum di atas.
      </p>

      <h2>12. Hukum yang berlaku</h2>
      <p>
        Syarat ini tunduk pada hukum Republik Indonesia. Pertanyaan atau keluhan dapat dikirim ke{" "}
        {KONTAK}.
      </p>

      <p>
        Lihat juga <Link href="/privasi">Kebijakan Privasi</Link>.
      </p>
    </LegalPage>
  );
}
