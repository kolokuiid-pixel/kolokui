"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { getBrowserClient } from "@/lib/supabase-browser";
import { useVisitor } from "@/lib/visitor-client";

const MIN_PASSWORD = 8;

export default function AturClient() {
  const router = useRouter();
  const visitor = useVisitor();
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (visitor.loading) return <p className="soft">Sebentar ya...</p>;

  if (!visitor.user) {
    return (
      <div className="auth-box">
        <p>Tautannya sudah kedaluwarsa, atau kamu belum masuk.</p>
        <p style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
          <Link href="/lupa-password" className="btn">
            Minta tautan baru
          </Link>
          <Link href="/masuk" className="btn btn-ghost">
            Masuk
          </Link>
        </p>
      </div>
    );
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    if (pw.length < MIN_PASSWORD) {
      setError(`Password minimal ${MIN_PASSWORD} karakter.`);
      return;
    }
    if (pw !== pw2) {
      setError("Kedua password belum sama.");
      return;
    }
    const sb = getBrowserClient();
    if (!sb) return;
    setBusy(true);
    const { error: err } = await sb.auth.updateUser({ password: pw });
    setBusy(false);
    if (err) {
      setError(/different from the old/i.test(err.message) ? "Pakai password yang berbeda dari yang lama." : err.message);
      return;
    }
    setDone(true);
    setTimeout(() => router.push("/akun"), 1500);
  }

  if (done) {
    return (
      <div className="auth-box">
        <p className="flash" role="status">Password sudah diganti.</p>
      </div>
    );
  }

  return (
    <form className="auth-box" onSubmit={submit}>
      <div className="field">
        <label htmlFor="pw">Password baru</label>
        <input id="pw" type="password" required minLength={MIN_PASSWORD} autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} />
        <span className="note">Minimal {MIN_PASSWORD} karakter.</span>
      </div>
      <div className="field">
        <label htmlFor="pw2">Ulangi password baru</label>
        <input id="pw2" type="password" required autoComplete="new-password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
      </div>
      <div>
        <button type="submit" className="btn" disabled={busy}>
          {busy ? "Menyimpan..." : "Simpan password"}
        </button>
      </div>
      {error ? <p className="flash flash-error" role="alert" style={{ margin: 0 }}>{error}</p> : null}
    </form>
  );
}
