import type { Metadata } from "next";
import Header from "@/components/Header";
import AturClient from "./AturClient";

export const metadata: Metadata = {
  title: "Password baru",
  robots: { index: false, follow: false },
};

export default function AturPasswordPage() {
  return (
    <>
      <Header />
      <main className="wrap">
        <div className="page-head">
          <h1 className="page-title">Password baru</h1>
        </div>
        <AturClient />
      </main>
    </>
  );
}
