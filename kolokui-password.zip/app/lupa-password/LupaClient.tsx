"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";
import { getBrowserClient } from "@/lib/supabase-browser";

export default function LupaClient() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const sb = getBrowserClient();
    if (!sb) {
      setError("Login belum diatur di server.");
      return;
    }
    setBusy(true);
    setError(null);
    const { error: err } = await sb.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/auth/confirm`,
    });
    setBusy(false);
    if (err) {
      setError(/rate limit|too many/i.test(err.message) ? "Terlalu banyak permintaan. Coba lagi beberapa menit lagi." : err.message);
    } else {
      setSent(true);
    }
  }

  if (sent) {
    return (
      <div className="auth-box">
        <p className="flash" role="status">
          Kalau email itu terdaftar, tautan untuk membuat password baru sudah dikirim. Cek
          inbox dan folder spam.
        </p>
        <p>
          <Link href="/masuk" className="btn btn-ghost">
            Kembali ke halaman masuk
          </Link>
        </p>
      </div>
    );
  }

  return (
    <form className="auth-box" onSubmit={submit}>
      <div className="field">
        <label htmlFor="email">Email</label>
        <input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <button type="submit" className="btn" disabled={busy}>
          {busy ? "Mengirim..." : "Kirim tautan"}
        </button>
      </div>
      {error ? <p className="flash flash-error" role="alert" style={{ margin: 0 }}>{error}</p> : null}
    </form>
  );
}
