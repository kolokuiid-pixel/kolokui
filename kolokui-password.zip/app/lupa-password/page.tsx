import type { Metadata } from "next";
import Header from "@/components/Header";
import LupaClient from "./LupaClient";

export const metadata: Metadata = {
  title: "Lupa password",
  robots: { index: false, follow: false },
};

export default function LupaPasswordPage() {
  return (
    <>
      <Header />
      <main className="wrap">
        <div className="page-head">
          <h1 className="page-title">Lupa password</h1>
          <p>Masukkan emailmu. Kami kirim tautan untuk membuat password baru.</p>
        </div>
        <LupaClient />
      </main>
    </>
  );
}
