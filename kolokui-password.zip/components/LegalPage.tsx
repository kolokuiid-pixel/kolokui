import Header from "@/components/Header";

export const KONTAK = process.env.NEXT_PUBLIC_CONTACT_EMAIL || "[isi email kontak di NEXT_PUBLIC_CONTACT_EMAIL]";
export const TERAKHIR_DIPERBARUI = "11 November 2026";

export default function LegalPage({
  judul,
  children,
}: {
  judul: string;
  children: React.ReactNode;
}) {
  return (
    <>
      <Header />
      <main className="wrap">
        <article className="article" style={{ paddingBottom: 96 }}>
          <h1>{judul}</h1>
          <p className="meta">Terakhir diperbarui: {TERAKHIR_DIPERBARUI}</p>
          <div className="prose">{children}</div>
        </article>
      </main>
    </>
  );
}
