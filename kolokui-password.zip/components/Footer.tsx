"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Footer() {
  const pathname = usePathname();
  if (pathname.startsWith("/admin")) return null;

  return (
    <div className="wrap">
      <footer className="site-footer">
        <span className="logo">Kolokui</span>
        <span>
          © {new Date().getFullYear()} Kolokui. Percakapan dengan Tuhan,
          sesama, dan hidup.
        </span>
        <span style={{ display: "flex", gap: 16 }}>
          <Link href="/privasi">Kebijakan Privasi</Link>
          <Link href="/syarat">Syarat dan Ketentuan</Link>
        </span>
      </footer>
    </div>
  );
}
